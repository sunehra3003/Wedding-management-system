// /js/ClientAuth.js
import { createClient } from 'https://esm.sh/@supabase/supabase-js'

const supabaseUrl = 'https://YOUR_URL.supabase.co'
const supabaseKey = 'YOUR_PUBLIC_ANON_KEY'
const supabase = createClient(supabaseUrl, supabaseKey)

export class ClientAuth {
  static async login(email, password) {
    const { error, data } = await supabase.auth.signInWithPassword({ email, password })
    if (error) throw error
    return data
  }

  static async signup(email, password) {
    const { error, data } = await supabase.auth.signUp({ email, password })
    if (error) throw error
    return data
  }

  static async logout() {
    const { error } = await supabase.auth.signOut()
    if (error) throw error
  }

  static async getSession() {
    const { data, error } = await supabase.auth.getSession()
    return data.session
  }
}
