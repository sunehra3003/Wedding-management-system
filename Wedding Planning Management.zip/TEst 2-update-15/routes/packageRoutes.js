import express from 'express';
import { createClient } from '@supabase/supabase-js';
import nodemailer from 'nodemailer';
import dotenv from 'dotenv';

dotenv.config(); // Load environment variables

const router = express.Router();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

// Setup Nodemailer transporter
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT, 10),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

router.post('/send-package-email', async (req, res) => {
  try {
    const {
      name,
      email,
      phone,
      package_name,
      price,
      appointment_date,
      notes,
    } = req.body;

    if (!name || !email || !phone || !package_name || !price || !appointment_date) {
      return res.status(400).json({ success: false, error: 'Missing required fields' });
    }

    const { error: insertError } = await supabase
      .from('package_purchases')
      .insert([
        {
          name,
          email,
          phone,
          package_name,
          price: parseFloat(price),
          appointment_date,
          notes,
          status: 'unpaid',
        },
      ]);

    if (insertError) {
      console.error('Supabase Insert Error:', insertError);
      return res.status(500).json({ success: false, error: 'Database insertion failed' });
    }

    // Prepare email messages
    const adminMailOptions = {
      from: `"Wedding Planner" <${process.env.SMTP_USER}>`,
      to: process.env.ADMIN_EMAIL,
      subject: `New Package Purchase: ${package_name}`,
      text: `
A new package purchase has been made:

Name: ${name}
Email: ${email}
Phone: ${phone}
Package: ${package_name}
Price: BDT. ${price}
Appointment Date: ${appointment_date}
Notes: ${notes || 'None'}
      `,
    };

    const clientMailOptions = {
      from: `"Wedding Planner" <${process.env.SMTP_USER}>`,
      to: email,
      subject: `Thank you for purchasing the ${package_name} package`,
      text: `
Dear ${name},

Thank you for purchasing the ${package_name} package.

We have recorded your appointment date as ${appointment_date}.

We will contact you shortly to confirm details.

Best regards,
Wedding Planner Team
      `,
    };

    await Promise.all([
      transporter.sendMail(adminMailOptions),
      transporter.sendMail(clientMailOptions),
    ]);

    return res.json({ success: true });
  } catch (err) {
    console.error('Error in /send-package-email:', err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
});

export default router;
