const express = require('express');
const router = express.Router();
const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  // Sign in with Supabase auth
  const { data: authData, error: authError } = await supabase.auth.signInWithPassword({ email, password });
  if (authError) return res.status(401).json({ message: 'Invalid login credentials' });

  // Get user role from your user table
  const { data: userData, error: userError } = await supabase
    .from('user')
    .select('id, email, role')
    .eq('email', email)
    .single();

  if (userError || !userData) {
    return res.status(403).json({ message: 'Access denied: User not found' });
  }

  res.json({ message: 'Login successful', role: userData.role });
});

module.exports = router;
