const express = require('express');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');
const { createClient } = require('@supabase/supabase-js');
const { sendEventEmails } = require('../utils/emailService2');
require('dotenv').config();

const router = express.Router();
const upload = multer();

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

// Utility to sanitize email for folder names
function sanitizeEmail(email) {
  return email.replace(/[@.]/g, '_');
}

// ✅ Uploads a file to Supabase Storage and returns a signed URL
async function uploadFile(file, folder, filename) {
  if (!file) return null;

  const ext = file.originalname.split('.').pop();
  const filePath = `${folder}/${filename}.${ext}`;

  // Use file.buffer (not the whole file object)
  const { error: uploadError } = await supabase.storage
    .from('event-files')
    .upload(filePath, file.buffer, {
      contentType: file.mimetype,
      upsert: true,
    });

  if (uploadError) {
    console.error('Upload error:', uploadError);
    throw uploadError;
  }

  const { data: urlData, error: urlError } = await supabase.storage
    .from('event-files')
    .createSignedUrl(filePath,60 * 60 * 24 * 7); // Valid for 1 hour

  if (urlError) {
    console.error('Signed URL error:', urlError);
    throw urlError;
  }

  return urlData.signedUrl;
}

router.post(
  '/send-event-email',
  upload.fields([
    { name: 'menu', maxCount: 1 },
    { name: 'decor', maxCount: 1 },
    { name: 'cake', maxCount: 1 },
    { name: 'card', maxCount: 1 },
  ]),
  async (req, res) => {
    try {
      const {
        type,
        bride,
        groom,
        venue,
        date,
        to,
        phone,
        budget,
        parlor,
        guest_count,
        music,
        services,
      } = req.body;

      const event_id = uuidv4();
      const folderName = `${sanitizeEmail(to)}/event_${event_id}`;

      // ✅ Upload files and get signed URLs
      const menu_url = await uploadFile(req.files['menu']?.[0], folderName, 'menu');
      const decor_url = await uploadFile(req.files['decor']?.[0], folderName, 'decor');
      const cake_url = await uploadFile(req.files['cake']?.[0], folderName, 'cake');
      const card_url = await uploadFile(req.files['card']?.[0], folderName, 'card');

      // ✅ Insert event details into Supabase DB
      const { error } = await supabase.from('event_orders').insert([{
        user_id: event_id,
        event_type: type,
        bride,
        groom,
        venue,
        date,
        user_email: to,
        phone,
        budget: Number(budget),
        parlor,
        guests: Number(guest_count),
        music,
        services,
        menu_url,
        decor_url,
        cake_url,
        card_url,
      }]);

      if (error) throw error;

      // ✅ Send emails
      await sendEventEmails({
        type,
        toEmail: to,
        bride,
        groom,
        venue,
        services,
        guest_count,
        budget,
        date,
      });

      res.status(200).json({
        success: true,
        message: 'Event submitted and emails sent.',
        event_id,
      });
    } catch (err) {
      console.error('Error:', err);
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

module.exports = router;
