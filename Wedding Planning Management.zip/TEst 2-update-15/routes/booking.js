const express = require('express');
const router = express.Router();
const { createClient } = require('@supabase/supabase-js');
const { sendClientEmail, sendAdminEmail } = require('../utils/emailService');

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

router.post('/book', async (req, res) => {
  const { name, email, date, requests, venue_slug, user_id } = req.body;

  if (!user_id) {
    return res.status(401).json({ error: 'User not authenticated.' });
  }

  const { error } = await supabase
    .from('venue_booking')
    .insert([{ name, email, date, requests, venue_slug, user_id }]);

  if (error) {
    return res.status(400).json({ error: error.message });
  }

  try {
    await sendClientEmail(email, name, venue_slug, date);
    await sendAdminEmail(process.env.ADMIN_EMAIL, name, venue_slug, date, email, requests);

    res.json({ success: true });
  } catch (err) {
    console.error('Email sending failed:', err);
    res.status(500).json({ error: 'Booking saved but email failed.' });
  }
});

module.exports = router;
