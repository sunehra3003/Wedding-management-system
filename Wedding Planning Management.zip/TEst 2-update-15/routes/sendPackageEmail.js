const express = require('express');
const { createClient } = require('@supabase/supabase-js');
const nodemailer = require('nodemailer');
require('dotenv').config();

const router = express.Router();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

router.post('/send-package-email', express.urlencoded({ extended: true }), async (req, res) => {
  try {
    const { name, email, phone, package_name, price, appointment_date, notes } = req.body;

    const { error: insertError } = await supabase
      .from('package_purchases')
      .insert([
        {
          name,
          email,
          phone,
          package_name,
          price: parseFloat(price),
          appointment_date,
          notes,
          status: 'unpaid',
        },
      ]);

    if (insertError) {
      console.error('Supabase Insert Error:', insertError);
      return res.status(500).json({ success: false, error: 'Database insertion failed' });
    }

    const adminMailOptions = {
      from: `"Wedding Planner" <${process.env.EMAIL_USER}>`,
      to: process.env.ADMIN_EMAIL,
      subject: `New Package Purchase: ${package_name}`,
      text: `
A new package purchase has been made:

Name: ${name}
Email: ${email}
Phone: ${phone}
Package: ${package_name}
Price: BDT. ${price}
Appointment Date: ${appointment_date}
Notes: ${notes || 'None'}
      `,
    };

    const clientMailOptions = {
      from: `"Wedding Planner" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: `Thank you for purchasing the ${package_name} package`,
      text: `
Dear ${name},

Thank you for purchasing the ${package_name} package.

We have recorded your appointment date as ${appointment_date}.

We will contact you shortly to confirm details.

Best regards,
Wedding Planner Team
      `,
    };

    await Promise.all([
      transporter.sendMail(adminMailOptions),
      transporter.sendMail(clientMailOptions),
    ]);

    return res.json({ success: true });
  } catch (err) {
    console.error('Error in /send-package-email:', err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
});

module.exports = router;
