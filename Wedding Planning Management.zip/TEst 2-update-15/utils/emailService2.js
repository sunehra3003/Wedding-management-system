const nodemailer = require('nodemailer');
require('dotenv').config();

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

async function sendEventEmails({ toEmail, bride, groom, venue, services, guest_count, budget, date, type }) {
  const name = `${bride} & ${groom}`;

  // Email to client
  await transporter.sendMail({
    from: `"Wedding Planner" <${process.env.EMAIL_USER}>`,
    to: toEmail,
    subject: `Your ${type} Booking Confirmation`,
    html: `
      <p>Dear ${name},</p>
      <p>Thank you for planning your <strong>${type}</strong> at <strong>${venue}</strong> on <strong>${date}</strong>.</p>
      <p>We’ll reach out shortly to finalize details.</p>
      <p>– Wedding Planner Team</p>
    `,
  });

  // Email to admin
  await transporter.sendMail({
    from: `"Wedding Planner" <${process.env.EMAIL_USER}>`,
    to: process.env.ADMIN_EMAIL,
    subject: `New ${type} Booking Received`,
    html: `
      <p><strong>${name}</strong> has booked a <strong>${type}</strong>.</p>
      <ul>
        <li><strong>Date:</strong> ${date}</li>
        <li><strong>Venue:</strong> ${venue}</li>
        <li><strong>Email:</strong> ${toEmail}</li>
        <li><strong>Guest Count:</strong> ${guest_count}</li>
        <li><strong>Budget:</strong> ${budget}</li>
        <li><strong>Services:</strong> ${services}</li>
      </ul>
    `,
  });
}

module.exports = { sendEventEmails };
