const nodemailer = require('nodemailer');
require('dotenv').config();

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

async function sendClientEmail(toEmail, name, venue, date) {
  await transporter.sendMail({
    from: `"Wedding Planner" <${process.env.EMAIL_USER}>`,
    to: toEmail,
    subject: 'Your Venue Booking Confirmation',
    html: `<p>Hi ${name},</p><p>Thank you for booking <strong>${venue}</strong> on <strong>${date}</strong>. We’ll be in touch!</p>`,
  });
}

async function sendAdminEmail(adminEmail, name, venue, date, email, requests) {
  await transporter.sendMail({
    from: `"Wedding Planner" <${process.env.EMAIL_USER}>`,
    to: adminEmail,
    subject: 'New Venue Booking Notification',
    html: `<p><strong>${name}</strong> booked <strong>${venue}</strong> on <strong>${date}</strong>.<br>Email: ${email}<br>Special Requests: ${requests}</p>`,
  });
}



module.exports = { sendClientEmail, sendAdminEmail };
