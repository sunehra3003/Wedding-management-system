const express = require("express");
const path = require("path");
const cors = require("cors");
const dotenv = require("dotenv");
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true })); // for parsing form-data
app.use(express.static("pages"));
app.use("/css", express.static(path.join(__dirname, "css")));
app.use("/images", express.static(path.join(__dirname, "images")));

// Routes
const sendEventEmailRoute = require("./routes/sendEventEmail");
const authRoutes = require("./routes/authRoutes");
const bookingRoutes = require("./routes/booking");
const sendPackageEmailRoute = require("./routes/sendPackageEmail"); // ✅ Add this line

// Mount your /api routes
app.use("/api", sendEventEmailRoute);
app.use("/api", sendPackageEmailRoute); // ✅ Mount here
app.use(authRoutes);
app.use(bookingRoutes);

// Page Routes
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "pages", "index.html"));
});
app.get("/reset-password", (req, res) => {
  res.sendFile(path.join(__dirname, "pages", "reset-password.html"));
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
